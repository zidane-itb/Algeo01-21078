package com.algeo;

import java.io.IOException;

public class MainProgram {

    public static void main(String[] args) throws NumberFormatException, UnsupportedOperationException, IOException {
        ProgramHandler.start();
    }
}
