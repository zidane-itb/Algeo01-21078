package com.algeo.lib;

import static java.lang.System.out;

public class Test {

    public static void main(String[] args) {
        Matrix matrix = new Matrix();
        matrix.loadMatrixLine();
        printMatrix(matrix.getEchelonMatrix().getMatrix());
        out.println(inferSolutionType(matrix.getEchelonMatrix().getMatrix()));

    }

    private static int inferSolutionType(double[][] matrix) {
        int type = -1, count = 0, lastIdx = matrix[0].length - 1, prevType = -1, i = 0;

        do {
            ++i;
            count = 0;
            for (double num : matrix[matrix.length - i]) {
                if (Math.abs(num) > 0.00001) ++count;
            }

            double lastEl = matrix[matrix.length - i][lastIdx];

            if (count == 0 || (count > 2 && !(Math.abs(lastEl) <= 0.0001)) || (count > 1 && (Math.abs(lastEl) <= 0.0001))) type = 2;

            if (count == 1 && !(Math.abs(lastEl) <= 0.0001) && type == -1) type = 0;

            if (count >= 1 && type == -1) type = 1;

            if (type == -1)
                throw new UnsupportedOperationException("error while inferring matrix's solution type");

            prevType = type;
        } while ((count == 0) && (matrix.length - i) >= 0);
        out.println(count);
        out.println(type);
        if (prevType == 2 && type != 0 && ((matrix[0].length - 1) != (matrix.length-i +1))) {
            type = prevType;
            out.println("sdasdas");
        }

        return type;
    }

    private static void printMatrix(double[][] matrix) {
        out.println();
        int horizontalSize = matrix[0].length;

        for (double[] doubles : matrix) {
            for (int j = 0; j < horizontalSize; ++j) {
                out.printf("%f ", doubles[j]);
            }
            out.println();
        }
        out.println();
    }
}
